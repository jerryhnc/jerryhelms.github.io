define([], function () {
    'use strict';
    return {
        qHyperCubeDef: {
            qInitialDataFetch: [{
                qWidth: 6,
                qHeight: 1500
            }]
        }
    };
});